res = lambda x, y: x + y
print(res(4, 5))

res = lambda x: '很man' if x == '男' else '很nice'

print(res('男'))
