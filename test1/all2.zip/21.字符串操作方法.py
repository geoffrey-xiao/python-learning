varstr = 'iloveyou=summer=youloveme'

# res = varstr.split('=',1)
# res = varstr.rsplit('=',1) 将字符串分割成列表

# varlist = ['i','love','you'] 将列表转化为字符串链接
# res = '&'.join(varlist)

varsplits = '****蜜雪冰城甜蜜蜜****'
res = varsplits.strip('*')

varcenter = '蜜雪冰城甜蜜蜜'
res= varcenter.center(15,'&')
print(res)