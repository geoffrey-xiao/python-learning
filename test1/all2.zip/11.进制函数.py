# 将十进制转化为二进制

# var1 = 6
# print(bin(var1))

# var1 = 0b110
# print(int(var1))
# 将十进制转化为八进制
var1 = 20
print(oct(var1))

# 将十进制转化为十六进制
print(hex(var1))

# 将字符转化为asscii码
var2 = 'a'
print(ord(var2))

print(chr(97))
