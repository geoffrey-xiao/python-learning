# 字符串+

var1 = '只是因为在人群之中看了你一眼,'
var2 = '再也没能忘掉你容颜'

res = var1 + var2
print(res)

# 字符串*
vars = 'summer'
print(vars * 3)
# 字符串切片操作【】

var3 = var1[3]
print(var3)

var4 = var1[2:6]

var5 = var1[2:8:2]

var6 = var1[::-1]
print(var4)
print(var5)
print(var6)
