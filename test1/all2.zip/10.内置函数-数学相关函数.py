# abs 绝对值

print(abs(-3))
# sum()求和函数
print(sum([3, 8]))

# max()求最大值 min()求最小值
print(max([34, 5, 6, 10]))
print(min([9, 20, 100, 90]))

# pow() 幂运算
print(pow(2, 3))

# round() 四舍五入运算,0.5奇数向上取整，偶数向下取整

print(round(3.1415926, 4))

print(round(2.5))
print(round(3.5))
