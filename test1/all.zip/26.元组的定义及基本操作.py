vars = (1,2,3,4,5,6,3)
# var1 = (1,)
# print(var1,type(var1))

# res = len(vars)
# res = vars.count(1)

# 元组的切片
# res = vars[1:5:2]
# res = vars[5:1:-2]

# index() 元素在元组的下标 只返回第一个
res = vars.index(3,4)
print(res)

