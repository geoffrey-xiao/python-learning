# 1.列表的定义[]或者list

# 2.判断是否在列表中

var1 = [1,2,3,4]
var2 = ['a','b','c','d']
# res = 1 in var1
# print(res)

# 3.列表相加 拼接
# res = var1+var2
# print(res)

# 4.列表相乘 重复
# res = var1*3
# print(res)

# 5.想列表追加元素 append（）
# var1.append(7)
# print(var1)

# 6.删除列表的某个元素
# del var1[2]
# print(var1)

# 7.删除列表的最后一个元素 pop
var1.pop()
print(var1)